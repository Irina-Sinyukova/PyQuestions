s= [1 ,2 ,3 ,1 ,4 ,4 ,1 ,5 ,6]
print(s.index(4))
