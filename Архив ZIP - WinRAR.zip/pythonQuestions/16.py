s= [ ' s ' , ' р ' , ' i ' , ' s ' , ' o ' , ' k ' ]
print(s [2:5])
print( s [:4])
print( s [2:])
print( s [ :-1])
