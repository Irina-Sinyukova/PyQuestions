users = {
    "Tom": {
        "phone": "+971478745",
        "email": "tom12@gmail.com"

    },
    "Bob": {
        "phone": "+876390444",
        "email": "bob@gmail.com",
        "skype": "bob123"
    }
}
print(users['Tom']['email'])
