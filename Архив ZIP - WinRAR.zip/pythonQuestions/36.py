s = input()
numbers = [int (i) for i in s.split()]
sp = list()
for num in numbers:
    if num % 2 !=0:
        sp.append(num)
sp.reverse()
print(sp)

#
print([num for num in [int(i) for i in s.split()] if num % 2 != 0] [::-1])