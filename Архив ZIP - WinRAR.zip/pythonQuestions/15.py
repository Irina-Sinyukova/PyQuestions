A= [1,2,3]
B = a.copy()
Print(a)
Print(b)
