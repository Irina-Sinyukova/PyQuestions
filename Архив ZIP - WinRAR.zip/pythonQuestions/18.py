s = list('Python')
for i in range(0, len(s)):
    print(s[i])
i = 0
while i < len(s):
    print(s[i])
i = i + 1
