users = {1:
         {'login': 'user1',
         'pass':1345,
         'FIO': 'Сергей Сергеев Сергеевич',
          'email' : 'user1@gmail.com'},
         2:
             {'login': 'user2',
         'pass':1345,
         'FIO': 'Олег Сергеев Сергеевич',
          'email' : 'user2@gmail.com'},
         }
print(users[1] ['email'])
users[3] = {'login': 'user3',
         'pass':1345,
         'FIO': 'Максим Сергеев Сергеевич',
          'email' : 'user3@gmail.com'}
for k, v in users[3].items():
    print(k, ':', v)

