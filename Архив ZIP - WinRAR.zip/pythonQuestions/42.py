s1 = 'aba'
print(s1 == s1[::-1])
s2 = s1.split()
s2.reverse()

print(s1 == ''.join(s2))