cartage = tuple(['a', 'd', 'v'])
if 'd' in cartage:
    print('YES')
else:
    print('NO')