s = input().split()
numbers = [int(el) for el in s]
mx = numbers.index(max(numbers))
mn = numbers.index(min(numbers))
print(numbers[mn + 1:mx])