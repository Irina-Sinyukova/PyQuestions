d = [1, 2, -3, -5, 6]
for i in range(len(d)):
    if d[i] < 0:
        d[i] = -d[i]
print(d)