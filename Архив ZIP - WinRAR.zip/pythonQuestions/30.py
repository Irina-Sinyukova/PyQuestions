s1=set('1234');
print(s1)
s1.add('5'); print(s1)
s1.remove('5'); print(s1)
s1.discard('4'); print(s1)
s1.pop(); print(s1)
s1.clear(); print(s1)