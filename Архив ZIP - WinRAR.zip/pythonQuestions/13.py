
s = [i for i in range (1 ,1,  1)]
