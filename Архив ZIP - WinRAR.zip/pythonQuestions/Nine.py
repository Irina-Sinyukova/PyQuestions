db_con='; '.join(['BG','MSSQLServer','1431','user','pswd'])
print(db_con)
