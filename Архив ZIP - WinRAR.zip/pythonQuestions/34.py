name = set('Ханна')
surname = set('Монтана')
print(name.intersection(surname))
print(name.symmetric_difference(surname))

