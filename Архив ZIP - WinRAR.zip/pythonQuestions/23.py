x = {}
for i in range(1, 10):
    x[i] = i**2
print(x[5])
print(x)